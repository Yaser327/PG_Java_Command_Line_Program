import java.util.Scanner;
import java.io.*;

public class owner
{
	public static int id=1;
  String fname, lname ,address, state, city, email_id, password, cpass,filename,pgfilename,pgname,desc,location;;
  char gender;
  Integer ph_no,type,price;
  String log_email, log_pass;
  Scanner sc=new Scanner(System.in);

    public void ownerMenu()
    {
        while (true)
        {
            int ch;
            System.out.println("\nChoose the Following Operations");
            System.out.println("1.Register\n");
            System.out.println("2.LOG IN\n");
            System.out.println("3.Main Menu\n");
            ch=sc.nextInt();

            //Switch case to display switch Operations
            switch(ch)
            {
                case 1:
                registration();
                break;

                case 2:
                login();
                break;

                case 3:
                System.out.print("Going back to Main Menu");
                Main.main(null);
                break;
                
                default:
                System.out.println("Invalid Choice");
            }
        }
    }
  
  

  public void registration()
	{
	  	
	  	try 
	  	{
	  		
        System.out.println("Enter the following details to Register Yourself: \n");

        System.out.println("Enter your First Name: ");
		    fname = sc.next();

	      filename = fname;

        //Writing Data into File
	  		BufferedWriter bw = new BufferedWriter(new FileWriter("OwnerRegistered/"+filename));

	  		
		    bw.write("First Name: " +fname);
		
		    System.out.println("\nEnter your Last Name: ");
		    lname = sc.next();
		    bw.write("\nLast Name: "+lname);
		
		    System.out.println("\nEnter your Gender M[Male] OR F[Female]: ");
		    gender = sc.next().charAt(0);
		    bw.write("\nGender: "+gender);
		
		    System.out.println("\nEnter your Phone number: ");
		    ph_no = sc.nextInt();
		    bw.write("\nPhone No: "+ph_no);
		
		    System.out.println("\nEnter your Address: ");
		    address = sc.next();
		    bw.write("\nAddress: "+address);
		
		    System.out.println("\nEnter your State: ");
		    state = sc.next();
		    bw.write("\nState: "+state);
		
		    System.out.println("\nEnter your City: ");
		    city = sc.next();
		     bw.write("\nCity: "+city);
		
		    System.out.println("\nEnter your Email ID: ");
		    email_id = sc.next();
		    log_email = email_id;
		    bw.write("\nEmail ID: \n"+email_id);
		
		    System.out.println("\nEnter Password: ");
		    password = sc.next();
		    bw.write("\nPassword: \n"+password);
		
		    System.out.println("\nConfirm your Password: ");
		    cpass = sc.next();
		    log_pass = password;

        String filename2 = "OwnerRegistered/AllOwners.txt";
		    File file = new File(filename2);
		    FileWriter fr = new FileWriter(file, true);
		    BufferedWriter bwu = new BufferedWriter((fr));
		    
        bwu.write(filename +"\n");

		    
		    bw.close();
		    bwu.close();
		    fr.close();
	  	}
	  	catch (Exception e) 
      {
        System.out.println("File OR Location Not Found!!\n");
      }       
	
		//Check if Passoword and Confirm Password Matches Or Not
		while(!password.equals(cpass))
		{
			System.out.println("Please Re-Enter Confirm Password");
			cpass = sc.next();
		}
	}

    public void display_details()
    {
        try
        {
            BufferedReader br = new BufferedReader(new FileReader("OwnerRegistered/"+filename));
            String str;
            
            System.out.print("\n");
            
            //To Read whole data from the File
            while((str = br.readLine()) != null)
            {
                System.out.println(str);
            }
            
        }
        catch (Exception e) 
        {
            System.out.println("File OR Location Not Found!!\n");
        }       
    } 

} 
     
    