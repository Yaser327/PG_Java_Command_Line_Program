
import java.util.Scanner;
import java.io.*;

public class Admin
{
	Scanner sc = new Scanner(System.in);

  public void adminMenu()
  {
    while(true)
    {
      System.out.println("\nChoose the Following Operations : \n1.Log IN\n2.Main Menu\n");
	    int ch=sc.nextInt();

      //switch case for operations
      switch(ch)
      {
        case 1:
          log_in();
        break;

        case 2:
          Main.main(null);
        break;

        default:
        System.out.println("Invalid Choice");
      }
    }
    
  }
	

	

}
