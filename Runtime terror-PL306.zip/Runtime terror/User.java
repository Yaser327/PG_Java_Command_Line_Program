import java.util.Scanner;
import java.io.*;

public class User
{
	
  String fname, lname ,address, state, city, email_id, password, cpass,filename;
  char gender;
  Integer ph_no;
  String log_email, log_pass;
  Scanner sc=new Scanner(System.in);

  public void UserMenu()
  {
    
     while (true)
     {
      int ch;
      System.out.println("\nChoose the Following Operations");
      System.out.println("1.Register\n");
      System.out.println("2.LOG IN\n");
      System.out.println("3.Main Menu\n");
      ch=sc.nextInt();

      //Switch case to display switch Operations
      switch(ch)
      {
        case 1:
          registration();
        break;

        case 2:
          login();
        break;

        case 3:
          System.out.print("Going back to Main Menu");
          Main.main(null);
        break;
        
        default:
        System.out.println("Invalid Choice");
      }
    }
    
  }
  

  public void display_details()
  {
    //    System.out.println("\n" + fname + " Your Registered Details are: ");
    //    System.out.println("\n First NAME: " + fname);
    //    System.out.println("\n Last NAME: " + lname);
    //    System.out.println("\n Gender: " + gender);
    //    System.out.println("\n Phone Number: " + ph_no);
    //    System.out.println("\n Address: " + address);
    //    System.out.println("\n State: " + state);
    //    System.out.println("\n City: " + city);
    //    System.out.println("\n Email ID: " + email_id);
    //    System.out.println("\n Password: " + password);
	  
	  try
	  {
		  BufferedReader br = new BufferedReader(new FileReader("UserRegistered/"+filename));
	    String str;

      System.out.print("\n");
	      
	    //To Read whole data from the File
      while((str = br.readLine()) != null)
      {
        System.out.println(str);
      }
	      
	  }
	  catch (Exception e) 
    {
      System.out.println("File OR Location Not Found!!\n");
    }       
	  
    
  } 

  public void login()
  {
		System.out.println("\n\nLogin Process...");
		 
		String fn,fname,lname,gender,phno,add,state,city,email,str,em, password,str1,pass;
		
		try 
		{
			
      System.out.print("\nEnter Your Registered First Name: ");
		  fn = sc.next();

      filename = fn;

      BufferedReader br = new BufferedReader(new FileReader("UserRegistered/"+filename));
		
			Scanner scan = new Scanner(br);
	
	    // To read the data Line by Line from the File
	    fname = scan.nextLine();
	    lname = scan.nextLine();
	    gender = scan.nextLine();
	    phno = scan.nextLine();
	    add = scan.nextLine();
	    state = scan.nextLine();
	    city = scan.nextLine();
	    str = scan.nextLine();
	    em = scan.nextLine();
	    str1 = scan.nextLine();
	    pass = scan.nextLine();
			
      
		  
      System.out.print("\nEnter Your Email_Id: ");
		  email = sc.next();
		
		  System.out.print("\nEnter Your Password: ");
		  password = sc.next();
		
		  while(!email.equals(em))
		  {
		    System.out.println("\nPlease Re-Enter Your Email ID ");
		    email = sc.next();
		  }
		
		  while(!password.equals(pass))
		  {
		    System.out.println("\nPlease Enter Correct Password ");
		    password = sc.next();
		  }
		
		  System.out.print("\n✅✅ LOG IN Successfull 👍\n");

      while(true)
      {
        int ch;
        System.out.println("\nChoose the Following Operations");
        System.out.println("1.View My Details");
        System.out.println("2.Main Menu");
        System.out.println("3.book pg");
        System.out.println("4.show my bookings");
        ch=sc.nextInt();
    
        //Switch case to display switch Operations
        switch(ch)
        {
          case 1:
            display_details();
          break;
      
          case 2:
            Main.main(null);
          break;

          case 3:
            pgbooking();
          break;

          case 4:
            display_booking();
          break;
      
          default:
            System.out.println("Invalid Choice");
        }
	    }
		}
		catch (Exception e) 
	  {
	    System.out.println("File OR Location Not Found!!\n");
	  }      
		
  }
     
  String bookpg;
  public void pgbooking()
  {
    try
    {
      // owner oo= new owner();
      String CheckIn, CheckOut;

      BufferedReader br = new BufferedReader(new FileReader("PGList/AllPGs.txt"));

      String str;

      System.out.print("\n");
	      
	    //To Read whole data from the File
      while((str = br.readLine()) != null)
      {
        System.out.println(str);
      }
      
      System.out.println("\nSelect the PG Name you want to book ");
      bookpg = sc.next();
      
      //Writing Data into File
      FileWriter fw = new FileWriter("BookingList/"+bookpg, true);
      BufferedWriter bww = new BufferedWriter(fw);
      PrintWriter bw = new PrintWriter(bww);
      
      
      bw.write("PG booked: \n" +bookpg);

      System.out.println("Enter Check In date in format(DD\\MM\\YY)");
      CheckIn = sc.next();
      bw.write("\nCheck In: " +CheckIn);

      System.out.println("Enter Check Out date in format(DD\\MM\\YY)");
      CheckOut = sc.next();
      bw.write("\nCheck Out: " +CheckOut);

      bw.write("\n");

      System.out.print("\nPG Booked Successfully");


      
      BufferedReader br1 = new BufferedReader(new FileReader("PGList/"+bookpg));

      String str1;

      System.out.print("\n");
	      
	    //To Read whole data from the File
      while((str1 = br.readLine()) != null)
      {
        System.out.println(str1);
      }
      
      br1.close();
      br.close();          
      bw.close();
    }
    catch (Exception e)
    {
      System.out.println("File OR Location Not Found!!\n");
    }   
  }

  public void display_booking()
  {
    try
    {
      String pgdetails;

      BufferedReader br = new BufferedReader(new FileReader("BookingList/"+bookpg));

      Scanner pgbookedscan = new Scanner(br);

      String title,pgname;
	
	    // To read the data Line by Line from the File
	    title = pgbookedscan.nextLine();
      pgname = pgbookedscan.nextLine();

      pgdetails = pgname;
      

      System.out.println("\n"+pgname);



      BufferedReader pgnamebr = new BufferedReader(new FileReader("PGList/"+ pgdetails));

      String str;

      //To Read whole data from the File
      while((str = br.readLine()) != null)
      {
        System.out.println(str);
      }

      pgnamebr.close();
      br.close();
            
    }
    catch (Exception e) 
    {
      System.out.println("File OR Location Not Found!!\n");
    }
    
  }
}
