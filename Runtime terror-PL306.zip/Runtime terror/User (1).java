import java.util.Scanner;
import java.io.*;

public class User
{
	
  String fname, lname ,address, state, city, email_id, password, cpass,filename;
  char gender;
  Integer ph_no;
  String log_email, log_pass;
  Scanner sc=new Scanner(System.in);

  

  public void registration()
	{
	  	
	  	try 
	  	{
	  		
        System.out.println("Enter the following details to Register Yourself: \n");

        System.out.println("Enter your First Name: ");
		    fname = sc.next();
        filename = fname;

        //Writing Data into File
	  		BufferedWriter bw = new BufferedWriter(new FileWriter("UserRegistered/"+ filename));

        bw.write("First Name: " +fname);

		    System.out.println("\nEnter your Last Name: ");
		    lname = sc.next();
		    bw.write("\nLast Name: "+lname);
		
		    System.out.println("\nEnter your Gender M[Male] OR F[Female]: ");
		    gender = sc.next().charAt(0);
		    bw.write("\nGender: "+gender);
		
		    System.out.println("\nEnter your Phone number: ");
		    ph_no = sc.nextInt();
		    bw.write("\nPhone No: "+ph_no);
		
		    System.out.println("\nEnter your Address: ");
		    address = sc.next();
		    bw.write("\nAddress: "+address);
		
		    System.out.println("\nEnter your State: ");
		    state = sc.next();
		    bw.write("\nState: "+state);
		
		    System.out.println("\nEnter your City: ");
		    city = sc.next();
		    bw.write("\nCity: "+city);
		
		    System.out.println("\nEnter your Email ID: ");
		    email_id = sc.next();
		    log_email = email_id;
		    bw.write("\nEmail ID: \n"+email_id);
		
		    System.out.println("\nEnter Password: ");
		    password = sc.next();
		    bw.write("\nPassword: \n"+password);
		
		    System.out.println("\nConfirm your Password: ");
		    cpass = sc.next();
		    log_pass = password;

		    String filename2 = "UserRegistered/AllUsers.txt";
		    File file = new File(filename2);
		    FileWriter fr = new FileWriter(file, true);
		    BufferedWriter bwu = new BufferedWriter((fr));
		    
        bwu.write(filename +"\n");

		    
		    bw.close();
		    bwu.close();
		    fr.close();
	  	}
	  	catch (Exception e) 
      {
        System.out.println("File OR Location Not Found!!\n");
      }       
	
		//Check if Passoword and Confirm Password Matches Or Not
		while(!password.equals(cpass))
		{
			System.out.println("Please Re-Enter Confirm Password");
			cpass = sc.next();
		}
	}

 
}
